Lovely for iPhone
--

Lovely app is not just another photo management app for your iPhone. It may not be the photos app you need. But it is the photos app you *deserve*.

Features:
--

- Browse and manage selfies
- Browse and manage screenshots
- Browse photos with faces
- View GIF
- Create GIF from your photos
- Create photostrip from your photos
- Batch resize (resize multiple photos easily)
- Batch delete (delete multiple photos easily)
- View complete photo's metadata (EXIF, location, etc)
- Edit photo with powerful tools including filters/effects, text overlay, stickers, crop, rotate, lighting/color adjustment, frames, sharpness/focus, vignette, blur, whiten, blemish, redeye removal, splash, and free drawing.
- Delightful UI animation and gesture.

Information
--

- Website: http://www.getlovelyapp.com
- Twitter: http://twitter.com/lovely_app
- App Store Link: https://itunes.apple.com/us/app/lovely-photos-management-gif/id970796506?ls=1&mt=8
- App Store Name: Lovely - Photos management with GIF creation, batch operations, screenshots management, and powerful editing tools
- Price: FREE with $5.99 IAP to remove ads and watermark.
- Requirement: iOS 8 or higher.

Contact
--

- Name: Nico Prananta
- Location: Japan
- Email: nico@delightfuldev.com
- Twitter: http://twitter.com/nicnocquee
- Blog: http://nicnocquee.com
